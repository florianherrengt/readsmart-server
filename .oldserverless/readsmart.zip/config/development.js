// @flow
import type { Config } from './index';

export const development: Config = {
    postgres: 'postgres://postgres@localhost:5432/postgres'
};
