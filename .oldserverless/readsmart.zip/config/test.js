// @flow
import type { Config } from './index';
export const test: Config = {
    postgres: 'postgres://postgres@localhost:5432/postgres'
};
