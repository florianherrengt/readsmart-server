// @flow
import { schema } from './schema';
import { resolvers } from './resolvers';

export { schema, resolvers };
